/*
 * sfuntmpl_basic.c: Basic 'C' template for a level 2 S-function.
 *
 * Copyright 1990-2018 The MathWorks, Inc.
 */


/*
 * You must specify the S_FUNCTION_NAME as the name of your S-function
 * (i.e. replace sfuntmpl_basic with the name of your S-function).
 */

#define S_FUNCTION_NAME  vMCU_sfunction
#define S_FUNCTION_LEVEL 2

/*
 * Need to include simstruc.h for the definition of the SimStruct and
 * its associated macro definitions.
 */
#include "simstruc.h"

#include "vMCU/virtualCode.h"

#define vPA_O_D_OFFSET 0
#define vPB_O_D_OFFSET 8
#define vPC_O_D_OFFSET 16
#define vPD_O_D_OFFSET 24
#define DEBUG_PORT_OFFSET 32

#define vPA_I_D_OFFSET 0
#define vPB_I_D_OFFSET 8
#define vPC_I_D_OFFSET 16
#define vPD_I_D_OFFSET 24
#define vPA_I_A_OFFSET 32

#define NUM_OUT_PORTS DEBUG_PORT_OFFSET+1
#define NUM_IN_PORTS vPA_I_A_OFFSET+8
/* Error handling
 * --------------
 *
 * You should use the following technique to report errors encountered within
 * an S-function:
 *
 *       ssSetErrorStatus(S,"Error encountered due to ...");
 *       return;
 *
 * Note that the 2nd argument to ssSetErrorStatus must be persistent memory.
 * It cannot be a local variable. For example the following will cause
 * unpredictable errors:
 *
 *      mdlOutputs()
 *      {
 *         char msg[256];         {ILLEGAL: to fix use "static char msg[256];"}
 *         sprintf(msg,"Error due to %s", string);
 *         ssSetErrorStatus(S,msg);
 *         return;
 *      }
 *
 */

/*====================*
 * S-function methods *
 *====================*/

/* Function: mdlInitializeSizes ===============================================
 * Abstract:
 *    The sizes information is used by Simulink to determine the S-function
 *    block's characteristics (number of inputs, outputs, states, etc.).
 */
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, 0);  /* Number of expected parameters */
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        /* Return if number of expected != number of actual parameters */
        return;
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    if (!ssSetNumInputPorts(S, NUM_IN_PORTS)) return;

	for(int i=0;i<8;i++)
	{
		ssSetInputPortWidth(S, vPA_I_D_OFFSET+i, 1);
		ssSetInputPortWidth(S, vPB_I_D_OFFSET+i, 1);
		ssSetInputPortWidth(S, vPC_I_D_OFFSET+i, 1);
		ssSetInputPortWidth(S, vPD_I_D_OFFSET+i, 1);
		ssSetInputPortWidth(S, vPA_I_A_OFFSET+i, 1);

		ssSetInputPortRequiredContiguous(S, vPA_I_D_OFFSET+i, true);
		ssSetInputPortRequiredContiguous(S, vPB_I_D_OFFSET+i, true);
		ssSetInputPortRequiredContiguous(S, vPC_I_D_OFFSET+i, true);
		ssSetInputPortRequiredContiguous(S, vPD_I_D_OFFSET+i, true);
		ssSetInputPortRequiredContiguous(S, vPA_I_A_OFFSET+i, true);

		ssSetInputPortDirectFeedThrough(S, vPA_I_D_OFFSET+i, 1);
		ssSetInputPortDirectFeedThrough(S, vPB_I_D_OFFSET+i, 1);
		ssSetInputPortDirectFeedThrough(S, vPC_I_D_OFFSET+i, 1);
		ssSetInputPortDirectFeedThrough(S, vPD_I_D_OFFSET+i, 1);
		ssSetInputPortDirectFeedThrough(S, vPA_I_A_OFFSET+i, 1);
	}
    
    
    /*
     * Set direct feedthrough flag (1=yes, 0=no).
     * A port has direct feedthrough if the input is used in either
     * the mdlOutputs or mdlGetTimeOfNextVarHit functions.
     */

    if (!ssSetNumOutputPorts(S, NUM_OUT_PORTS)) return;

	for(int i=0;i<8;i++)
	{
		ssSetOutputPortWidth(S, vPA_O_D_OFFSET+i, 1);
		ssSetOutputPortWidth(S, vPB_O_D_OFFSET+i, 1);
		ssSetOutputPortWidth(S, vPC_O_D_OFFSET+i, 1);
		ssSetOutputPortWidth(S, vPD_O_D_OFFSET+i, 1);
	}
	ssSetOutputPortWidth(S, DEBUG_PORT_OFFSET, 1);

    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, 0);
    ssSetNumIWork(S, 1);
    ssSetNumPWork(S, 3);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    /* Specify the operating point save/restore compliance to be same as a 
     * built-in block */
    ssSetOperatingPointCompliance(S, USE_DEFAULT_OPERATING_POINT);

    ssSetOptions(S, 0);
}



/* Function: mdlInitializeSampleTimes =========================================
 * Abstract:
 *    This function is used to specify the sample time(s) for your
 *    S-function. You must register the same number of sample times as
 *    specified in ssSetNumSampleTimes.
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    //ssSetSampleTime(S, 0, CONTINUOUS_SAMPLE_TIME);
    ssSetSampleTime(S, 0, 0.000000125);
	ssSetOffsetTime(S, 0, 0.0);

}



#define MDL_INITIALIZE_CONDITIONS   /* Change to #undef to remove function */
#if defined(MDL_INITIALIZE_CONDITIONS)
  /* Function: mdlInitializeConditions ========================================
   * Abstract:
   *    In this function, you should initialize the continuous and discrete
   *    states for your S-function block.  The initial states are placed
   *    in the state vector, ssGetContStates(S) or ssGetRealDiscStates(S).
   *    You can also perform any other initialization activities that your
   *    S-function may require. Note, this routine will be called at the
   *    start of simulation and if it is present in an enabled subsystem
   *    configured to reset states, it will be call when the enabled subsystem
   *    restarts execution to reset the states.
   */
  static void mdlInitializeConditions(SimStruct *S)
  {
    VirtualCode* virtualCode = new VirtualCode();
	sInports* varInports = new sInports;
	sOutports* varOutports = new sOutports;
    ssSetPWorkValue(S, 0, (void*) virtualCode);
	ssSetPWorkValue(S, 1, (void*) varInports);
	ssSetPWorkValue(S, 2, (void*) varOutports);
	ssSetIWorkValue(S, 0, 1);
  }
#endif /* MDL_INITIALIZE_CONDITIONS */



#define MDL_START  /* Change to #undef to remove function */
#if defined(MDL_START) 
  /* Function: mdlStart =======================================================
   * Abstract:
   *    This function is called once at start of model execution. If you
   *    have states that should be initialized once, this is the place
   *    to do it.
   */
  static void mdlStart(SimStruct *S)
  {
      //const sDataStorage* pVarDataStorage = (sDataStorage*)ssGetPWorkValue(S, 0);
      
  }
#endif /*  MDL_START */



/* Function: mdlOutputs =======================================================
 * Abstract:
 *    In this function, you compute the outputs of your S-function
 *    block.
 */
static void mdlOutputs(SimStruct *S, int_T tid)
{
    //const real_T *u = (const real_T*) ssGetInputPortSignal(S,0);
    VirtualCode* virtualCode = (VirtualCode*)ssGetPWorkValue(S, 0);
	sInports* varInports = (sInports*)ssGetPWorkValue(S, 1);
	sOutports* varOutports = (sOutports*)ssGetPWorkValue(S, 2);

	int_T counter = ssGetIWorkValue(S, 0);
	ssSetIWorkValue(S, 0, counter+1);
	real_T* vPA_O_D[8];
	real_T* vPB_O_D[8];
	real_T* vPC_O_D[8];
	real_T* vPD_O_D[8];

	real_T* vPA_I_D[8];
	real_T* vPB_I_D[8];
	real_T* vPC_I_D[8];
	real_T* vPD_I_D[8];
	real_T* vPA_I_A[8];

	int i;

	for(i=0;i<8;i++)
	{
		vPA_O_D[i] = (real_T*) ssGetOutputPortSignal(S,vPA_O_D_OFFSET + i);
		vPB_O_D[i] = (real_T*) ssGetOutputPortSignal(S,vPB_O_D_OFFSET + i);
		vPC_O_D[i] = (real_T*) ssGetOutputPortSignal(S,vPC_O_D_OFFSET + i);
		vPD_O_D[i] = (real_T*) ssGetOutputPortSignal(S,vPD_O_D_OFFSET + i);

		vPA_I_D[i] = (real_T*) ssGetInputPortSignal(S,vPA_I_D_OFFSET + i);
		vPB_I_D[i] = (real_T*) ssGetInputPortSignal(S,vPB_I_D_OFFSET + i);
		vPC_I_D[i] = (real_T*) ssGetInputPortSignal(S,vPC_I_D_OFFSET + i);
		vPD_I_D[i] = (real_T*) ssGetInputPortSignal(S,vPD_I_D_OFFSET + i);
		vPA_I_A[i] = (real_T*) ssGetInputPortSignal(S,vPA_I_A_OFFSET + i);
	}
	real_T       *DEBUG = (real_T*) ssGetOutputPortSignal(S,DEBUG_PORT_OFFSET);

	for(i=0;i<8;i++)
	{
		varInports->vPA_I_A[i] = vPA_I_A[i][0] * 1000;
		varInports->vPA_I_D[i] = vPA_I_D[i][0];
		varInports->vPB_I_D[i] = vPB_I_D[i][0];
		varInports->vPC_I_D[i] = vPC_I_D[i][0];
		varInports->vPD_I_D[i] = vPD_I_D[i][0];
	}

	virtualCode->decodeInports(varInports, varOutports);
	virtualCode->stepProcess();
	virtualCode->encodeOutports(varOutports);
	

	for(i=0;i<8;i++)
	{

		vPA_O_D[i][0] = varOutports->vPA_O_D[i];
		vPB_O_D[i][0] = varOutports->vPB_O_D[i];
		vPC_O_D[i][0] = varOutports->vPC_O_D[i];
		vPD_O_D[i][0] = varOutports->vPD_O_D[i];
	}
	

	
	DEBUG[0] = virtualCode->DEBUG_PORT;
	

}



#define MDL_UPDATE  /* Change to #undef to remove function */
#if defined(MDL_UPDATE)
  /* Function: mdlUpdate ======================================================
   * Abstract:
   *    This function is called once for every major integration time step.
   *    Discrete states are typically updated here, but this function is useful
   *    for performing any tasks that should only take place once per
   *    integration step.
   */
  static void mdlUpdate(SimStruct *S, int_T tid)
  {
  }
#endif /* MDL_UPDATE */



#define MDL_DERIVATIVES  /* Change to #undef to remove function */
#if defined(MDL_DERIVATIVES)
  /* Function: mdlDerivatives =================================================
   * Abstract:
   *    In this function, you compute the S-function block's derivatives.
   *    The derivatives are placed in the derivative vector, ssGetdX(S).
   */
  static void mdlDerivatives(SimStruct *S)
  {
  }
#endif /* MDL_DERIVATIVES */



/* Function: mdlTerminate =====================================================
 * Abstract:
 *    In this function, you should perform any actions that are necessary
 *    at the termination of a simulation.  For example, if memory was
 *    allocated in mdlStart, this is the place to free it.
 */
static void mdlTerminate(SimStruct *S)
{
}


/*=============================*
 * Required S-function trailer *
 *=============================*/

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
